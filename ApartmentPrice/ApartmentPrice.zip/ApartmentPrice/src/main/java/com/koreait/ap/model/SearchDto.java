package com.koreait.ap.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SearchDto {
    private int year;
    private int month;
    private String out_code;
}
