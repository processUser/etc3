package com.koreait.ap.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LocationCodeEntity {
    private int in_code;
    private String out_code;
    private String nm;
}
